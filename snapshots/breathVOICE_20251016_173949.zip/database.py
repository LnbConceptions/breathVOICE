import sqlite3

def initialize_database():
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    # Create characters table
    c.execute('''
        CREATE TABLE IF NOT EXISTS characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            avatar_path TEXT
        )
    ''')
    # Create llm_configs table
    c.execute('''
            CREATE TABLE IF NOT EXISTS llm_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                url TEXT NOT NULL,
                api_key TEXT NOT NULL,
                model TEXT NOT NULL
            )
        ''')
    # Create dialogue_sets table
    c.execute('''
        CREATE TABLE IF NOT EXISTS dialogue_sets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            character_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            FOREIGN KEY (character_id) REFERENCES characters (id)
        )
    ''')
    # Create dialogues table
    c.execute('''
        CREATE TABLE IF NOT EXISTS dialogues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            set_id INTEGER NOT NULL,
            action_parameter TEXT NOT NULL,
            dialogue TEXT NOT NULL,
            FOREIGN KEY (set_id) REFERENCES dialogue_sets (id)
        )
    ''')
    conn.commit()
    conn.close()

def create_character(name, description, avatar_path=None):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("INSERT INTO characters (name, description, avatar_path) VALUES (?, ?, ?)", (name, description, avatar_path))
    conn.commit()
    conn.close()

def get_characters():
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM characters")
    characters = c.fetchall()
    conn.close()
    return characters

def update_character(character_id, name, description, avatar_path=None):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("UPDATE characters SET name = ?, description = ?, avatar_path = ? WHERE id = ?", (name, description, avatar_path, character_id))
    conn.commit()
    conn.close()

def delete_character(character_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("DELETE FROM characters WHERE id = ?", (character_id,))
    conn.commit()
    conn.close()

def get_character(character_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM characters WHERE id = ?", (character_id,))
    character = c.fetchone()
    conn.close()
    return character

def create_llm_config(name, url, api_key, model):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("INSERT INTO llm_configs (name, url, api_key, model) VALUES (?, ?, ?, ?)", (name, url, api_key, model))
    conn.commit()
    conn.close()

def get_llm_configs():
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM llm_configs")
    configs = c.fetchall()
    conn.close()
    return configs

def get_llm_config_by_name(name):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM llm_configs WHERE name = ?", (name,))
    config = c.fetchone()
    conn.close()
    return config

def get_llm_config(config_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM llm_configs WHERE id = ?", (config_id,))
    config = c.fetchone()
    conn.close()
    return config

def update_llm_config(name, url, api_key, model):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("UPDATE llm_configs SET url = ?, api_key = ?, model = ? WHERE name = ?", (url, api_key, model, name))
    conn.commit()
    conn.close()

def delete_llm_config(name):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("DELETE FROM llm_configs WHERE name = ?", (name,))
    conn.commit()
    conn.close()

def create_dialogue_set(character_id, name):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("INSERT INTO dialogue_sets (character_id, name) VALUES (?, ?)", (character_id, name))
    set_id = c.lastrowid
    conn.commit()
    conn.close()
    return set_id

def get_dialogue_sets(character_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT * FROM dialogue_sets WHERE character_id = ?", (character_id,))
    sets = c.fetchall()
    conn.close()
    return sets

def delete_dialogue_set(set_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("DELETE FROM dialogues WHERE set_id = ?", (set_id,))
    c.execute("DELETE FROM dialogue_sets WHERE id = ?", (set_id,))
    conn.commit()
    conn.close()

def create_dialogue(set_id, action_parameter, dialogue):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("INSERT INTO dialogues (set_id, action_parameter, dialogue) VALUES (?, ?, ?)", (set_id, action_parameter, dialogue))
    conn.commit()
    conn.close()

def get_dialogues(set_id):
    conn = sqlite3.connect('voice_pack.db')
    c = conn.cursor()
    c.execute("SELECT action_parameter, dialogue FROM dialogues WHERE set_id = ?", (set_id,))
    dialogues = c.fetchall()
    conn.close()
    return dialogues

if __name__ == '__main__':
    initialize_database()