import gradio as gr
import pandas as pd
import openai
import json
import zipfile
import shutil
import database as db
import os
from datetime import datetime
import unicodedata
import re
from typing import Any

# ---- Gradio Client JSON schema safety patch ----
# Some environments yield boolean values for `additionalProperties` in JSON Schema,
# which causes `gradio_client.utils.json_schema_to_python_type` to iterate over a bool
# and crash during app startup (resulting in HTTP 500). We defensively patch the
# helper to gracefully handle booleans and non-dict inputs.
try:
    import gradio_client.utils as gc_utils
    _orig_inner = getattr(gc_utils, "_json_schema_to_python_type", None)
    _file_fmt = getattr(gc_utils, "CURRENT_FILE_DATA_FORMAT", None)

    if _orig_inner is not None:
        def _safe_inner(schema: Any, defs: Any = None) -> str:
            if isinstance(schema, bool):
                # True/False for additionalProperties => allow arbitrary/none
                return "Any" if schema else "None"
            if not isinstance(schema, dict):
                return "Any"
            return _orig_inner(schema, defs)

        def safe_json_schema_to_python_type(schema: Any) -> str:
            try:
                if isinstance(schema, bool):
                    t = "Any" if schema else "None"
                elif isinstance(schema, dict):
                    t = _safe_inner(schema, schema.get("$defs"))
                else:
                    t = "Any"
                if isinstance(_file_fmt, str):
                    t = t.replace(_file_fmt, "filepath")
                return t
            except Exception:
                return "Any"

        gc_utils._json_schema_to_python_type = _safe_inner
        gc_utils.json_schema_to_python_type = safe_json_schema_to_python_type
except Exception as _schema_patch_err:
    print("[Warn] Failed to patch gradio_client JSON schema utils:", _schema_patch_err)

def create_character(name, description, avatar_path):
    if name and description:
        db.create_character(name, description, avatar_path)
        return "Character created successfully!"
    else:
        return "Name and description are required."

def update_character_list():
    characters = db.get_characters()
    return gr.update(value=characters)

def get_characters_for_update():
    characters = db.get_characters()
    return gr.update(choices=[(c[1], c[0]) for c in characters])

def update_character_fields(character_id):
    character = db.get_character(character_id)
    if character:
        return character[1], character[2], character[3]
    return "", "", None

def update_character(character_id, name, description, avatar_path):
    if character_id and name and description:
        db.update_character(character_id, name, description, avatar_path)
        update_character_list()
        return "Character updated successfully."
    return "Failed to update character."

def delete_character(evt: gr.SelectData, character_list_df):
    if evt.index is not None:
        character_id = character_list_df.iloc[evt.index[0]][0]
        db.delete_character(character_id)
        return "Character deleted successfully."
    return "No character selected."

def character_ui():
    with gr.Blocks() as character_ui_block:
        with gr.Row():
            with gr.Column():
                gr.Markdown("### Create Character")
                character_name = gr.Textbox(label="Character Name")
                character_description = gr.Textbox(label="Character Description", lines=3)
                character_avatar = gr.Image(label="Character Avatar", type="filepath")
                create_button = gr.Button("Create Character")
                creation_status = gr.Textbox(label="Status", interactive=False)
                test_button = gr.Button("Test Button")
            with gr.Column():
                gr.Markdown("### Manage Characters")
                character_list = gr.Dataframe(headers=["ID", "Name", "Description", "Avatar"], col_count=(4, "fixed"))
                delete_button = gr.Button("Delete Selected Character")
        with gr.Row():
            with gr.Column():
                gr.Markdown("### Update Character")
                update_character_id = gr.Dropdown(label="Select Character to Update")
                update_character_name = gr.Textbox(label="New Name")
                update_character_description = gr.Textbox(label="New Description", lines=3)
                update_character_avatar = gr.Image(label="New Avatar", type="filepath")
                update_button = gr.Button("Update Character")

        def test_click():
            print("Test button clicked!")

        create_button.click(create_character, [character_name, character_description, character_avatar], creation_status).then(update_character_list, None, character_list)
        delete_button.click(delete_character, [character_list], None).then(update_character_list, None, character_list)
        test_button.click(test_click, [], [])

        character_ui_block.load(update_character_list, None, character_list)
        character_ui_block.load(get_characters_for_update, None, update_character_id)
        update_character_id.change(update_character_fields, update_character_id, [update_character_name, update_character_description, update_character_avatar])
        update_button.click(update_character, [update_character_id, update_character_name, update_character_description, update_character_avatar], None).then(update_character_list, None, character_list)

    return character_ui_block

def llm_config_ui():
    with gr.Blocks() as llm_config_interface:
        gr.Markdown("## LLM Configuration")
        
        # 页面顶部的三个输入框和两个按钮
        with gr.Row():
            url_input = gr.Textbox(label="API URL", placeholder="https://api.openai.com/v1")
            key_input = gr.Textbox(label="API Key", type="password")
            model_dropdown = gr.Dropdown(label="Select Model", choices=[])
        
        with gr.Row():
            fetch_models_button = gr.Button("Fetch Models")
            test_button = gr.Button("Test Availability")
        
        # 状态显示
        status_output = gr.Textbox(label="Status", interactive=False)
        
        # API Configurations 部分
        gr.Markdown("### API Configurations")
        with gr.Row():
            config_dropdown = gr.Dropdown(label="API Configurations", choices=["None"], value="None")
            new_button = gr.Button("新建")
            save_button = gr.Button("保存", interactive=False)
            edit_button = gr.Button("编辑", interactive=False)
            delete_button = gr.Button("删除", interactive=False)

        # 隐藏的弹窗组件
        with gr.Column(visible=False) as new_config_modal:
            gr.Markdown("### 新建配置")
            new_config_name = gr.Textbox(label="配置名称")
            with gr.Row():
                save_new_button = gr.Button("保存")
                cancel_new_button = gr.Button("取消")
        
        with gr.Column(visible=False) as edit_config_modal:
            gr.Markdown("### 编辑配置")
            edit_config_name = gr.Textbox(label="配置名称")
            edit_api_url = gr.Textbox(label="API URL", interactive=False)
            edit_api_key = gr.Textbox(label="API Key", interactive=False, type="password")
            edit_model = gr.Textbox(label="Select Model", interactive=False)
            with gr.Row():
                save_edit_button = gr.Button("保存")
                cancel_edit_button = gr.Button("取消")
        
        with gr.Column(visible=False) as delete_config_modal:
             gr.Markdown("### 删除确认")
             delete_confirm_text = gr.Markdown("")
             with gr.Row():
                 confirm_delete_button = gr.Button("删除")
                 cancel_delete_button = gr.Button("取消")

        # 功能函数
        def update_config_dropdown():
            configs = db.get_llm_configs()
            # 提取配置名称 (第二列是name字段)
            config_names = [config[1] for config in configs] if configs else []
            choices = ["None"] + config_names
            return gr.update(choices=choices)

        def fetch_models(url, api_key):
            if not url or not api_key:
                return gr.update(choices=[]), "API URL and Key are required."
            if not url.endswith('/v1'):
                return gr.update(choices=[]), "URL must end with '/v1'"
            try:
                client = openai.OpenAI(base_url=url, api_key=api_key)
                models = client.models.list()
                return gr.update(choices=[model.id for model in models.data]), "Models fetched successfully!"
            except Exception as e:
                return gr.update(choices=[]), f"Error: {e}"

        def test_availability(url, api_key, model):
            if not url or not api_key or not model:
                return "URL, API Key, and Model are required to test."
            try:
                client = openai.OpenAI(base_url=url, api_key=api_key)
                client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": "Hello"}]
                )
                return "Model is available!"
            except Exception as e:
                return f"Error: {e}"

        def update_button_states(selected_config):
            if selected_config == "None":
                return gr.update(interactive=False), gr.update(interactive=False), gr.update(interactive=False)
            else:
                return gr.update(interactive=True), gr.update(interactive=True), gr.update(interactive=True)

        def load_config_data(selected_config):
            if selected_config == "None":
                return "", "", gr.update(choices=[])
            config = db.get_llm_config_by_name(selected_config)
            if config:
                return config[2], config[3], gr.update(choices=[config[4]], value=config[4])
            return "", "", gr.update(choices=[])

        # 事件绑定
        llm_config_interface.load(update_config_dropdown, None, config_dropdown)
        fetch_models_button.click(fetch_models, [url_input, key_input], [model_dropdown, status_output])
        test_button.click(test_availability, [url_input, key_input, model_dropdown], status_output)
        config_dropdown.change(update_button_states, config_dropdown, [save_button, edit_button, delete_button])
        config_dropdown.change(load_config_data, config_dropdown, [url_input, key_input, model_dropdown])

        # 弹窗功能函数
        def show_new_modal():
            return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False)

        def hide_new_modal():
            return gr.update(visible=False), ""

        def save_new_config(name, url, api_key, model):
            if not name or not url or not api_key or not model:
                return gr.update(visible=True), "所有字段都是必填的。"
            try:
                db.create_llm_config(name, url, api_key, model)
                return gr.update(visible=False), f"配置 '{name}' 已保存。", update_config_dropdown()
            except Exception as e:
                return gr.update(visible=True), f"保存失败: {e}"

        def show_edit_modal(selected_config):
            if selected_config == "None":
                return gr.update(visible=False), "", "", "", ""
            config = db.get_llm_config_by_name(selected_config)
            if config:
                return gr.update(visible=True), config[1], config[2], config[3], config[4]
            return gr.update(visible=False), "", "", "", ""

        def hide_edit_modal():
            return gr.update(visible=False)

        def save_edit_config(old_name, new_name, url, api_key, model):
            if not new_name:
                return gr.update(visible=True), "配置名称不能为空。"
            try:
                # 删除旧配置，创建新配置
                db.delete_llm_config(old_name)
                db.create_llm_config(new_name, url, api_key, model)
                return gr.update(visible=False), f"配置已更新为 '{new_name}'。", update_config_dropdown()
            except Exception as e:
                return gr.update(visible=True), f"更新失败: {e}"

        def show_delete_modal(selected_config):
            if selected_config == "None":
                return gr.update(visible=False), ""
            return gr.update(visible=True), f"确定要删除配置 '{selected_config}' 吗？"

        def hide_delete_modal():
            return gr.update(visible=False)

        def confirm_delete_config(selected_config):
            try:
                db.delete_llm_config(selected_config)
                return gr.update(visible=False), f"配置 '{selected_config}' 已删除。", update_config_dropdown(), gr.update(value="None")
            except Exception as e:
                return gr.update(visible=True), f"删除失败: {e}"

        def save_current_config(selected_config, url, api_key, model):
            if selected_config == "None":
                return "请先选择一个配置。"
            if not url or not api_key or not model:
                return "URL、API Key 和 Model 都是必填的。"
            try:
                db.update_llm_config(selected_config, url, api_key, model)
                return f"配置 '{selected_config}' 已更新。"
            except Exception as e:
                return f"保存失败: {e}"

        # 弹窗事件绑定
        new_button.click(show_new_modal, None, [new_config_modal, edit_config_modal, delete_config_modal])
        cancel_new_button.click(hide_new_modal, None, [new_config_modal, new_config_name])
        save_new_button.click(save_new_config, [new_config_name, url_input, key_input, model_dropdown], [new_config_modal, status_output, config_dropdown])

        edit_button.click(show_edit_modal, config_dropdown, [edit_config_modal, edit_config_name, edit_api_url, edit_api_key, edit_model])
        cancel_edit_button.click(hide_edit_modal, None, edit_config_modal)
        save_edit_button.click(save_edit_config, [config_dropdown, edit_config_name, edit_api_url, edit_api_key, edit_model], [edit_config_modal, status_output, config_dropdown])

        delete_button.click(show_delete_modal, config_dropdown, [delete_config_modal, delete_confirm_text])
        cancel_delete_button.click(hide_delete_modal, None, delete_config_modal)
        confirm_delete_button.click(confirm_delete_config, config_dropdown, [delete_config_modal, status_output, config_dropdown, config_dropdown])

        save_button.click(save_current_config, [config_dropdown, url_input, key_input, model_dropdown], status_output)

    return llm_config_interface

def dialogue_generation_ui():
    # 预先加载并展示所有172个固定动作参数，右侧列初始为"等待生成..."
    try:
        from action_parameters import ALL_ACTION_PARAMS
        initial_data = [[False, param, "等待生成..."] for param in ALL_ACTION_PARAMS]
        initial_df = pd.DataFrame(initial_data, columns=["选择", "动作参数", "台词"])  # 默认中文列名，增加选择列
    except Exception as e:
        print(f"加载动作参数失败: {e}")
        initial_df = pd.DataFrame(columns=["选择", "动作参数", "台词"])  # 回退为空表
    
    # 全局状态变量
    generation_state = {"is_running": False, "stop_requested": False}
    
    with gr.Blocks() as dialogue_generation_interface:
        gr.Markdown("## Step 3: Generate Dialogue")
        with gr.Row():
            character_dropdown = gr.Dropdown(label="Select Character")
            with gr.Row():
                llm_config_dropdown = gr.Dropdown(label="Select LLM Configuration", scale=4)
                refresh_llm_button = gr.Button("🔄", scale=1, size="sm", variant="secondary")
        language_dropdown = gr.Dropdown(label="台词语言", choices=["中文", "English", "日本語"], value="中文")
        
        # 添加两个新的信息栏
        with gr.Row():
            with gr.Column():
                generation_status = gr.Textbox(
                    label="🔄 当前生成状态", 
                    value="等待开始生成...", 
                    interactive=False,
                    lines=15,
                    max_lines=15
                )
            with gr.Column():
                prompt_preview = gr.Textbox(
                    label="📝 提示词预览", 
                    value="请先选择角色、API配置和语言", 
                    interactive=False,
                    lines=15,
                    max_lines=15
                )
        
        # 动态按钮：生成 与 停止
        with gr.Row():
            generate_button = gr.Button("Generate Dialogue", variant="primary")
            stop_button = gr.Button("Stop Generate", variant="secondary", interactive=True)
        status_output = gr.Textbox(label="Status", interactive=False)
        
        # 实时表格显示：加入“选择”列（勾选框），其他列保持只读
        dialogue_df = gr.Dataframe(
            label="Generated Dialogue", 
            headers=["选择", "动作参数", "台词"], 
            datatype=["bool", "str", "str"],
            interactive=True,   # 允许仅第一列可交互（通过CSS禁用其他列编辑）
            wrap=True,          # 允许文本换行
            value=initial_df,
            elem_id="generated_dialogue_df"
        )

        # 默认列宽样式（用户可调整）
        table_style = gr.HTML(value=f"""
<style>
  /* 容器允许横向滚动，固定布局避免列宽被内容撑破 */
  #generated_dialogue_df {{ overflow-x: auto; }}
  #generated_dialogue_df table {{ table-layout: fixed; width: 100%; }}

  /* 选择列固定较窄宽度，其余列宽使用CSS变量，便于后续通过控件调整 */
  #generated_dialogue_df table thead th:nth-child(1),
  #generated_dialogue_df table tbody td:nth-child(1) {{ width: 90px !important; }}
  #generated_dialogue_df table thead th:nth-child(2),
  #generated_dialogue_df table tbody td:nth-child(2) {{ width: 220px !important; }}
  #generated_dialogue_df table thead th:nth-child(3),
  #generated_dialogue_df table tbody td:nth-child(3) {{ width: 600px !important; }}

  /* 文本换行和断词优化，避免溢出 */
  #generated_dialogue_df table td, 
  #generated_dialogue_df table th {{ white-space: normal; word-break: break-word; }}

  /* 禁用除第一列外的编辑交互，仅允许勾选复选框 */
  #generated_dialogue_df table tbody td:nth-child(2) *,
  #generated_dialogue_df table tbody td:nth-child(3) * {{ pointer-events: none; user-select: text; }}
</style>
        """)

        # 列宽改为固定默认值（移除用户可调控件）
        
        with gr.Row():
            save_dialogue_set_button = gr.Button("Save Dialogue Set")
        with gr.Row():
            load_dialogue_set_dropdown = gr.Dropdown(label="Load Dialogue Set")
            delete_dialogue_set_button = gr.Button("Delete Dialogue Set")
        with gr.Row():
            export_csv_button = gr.Button("Export to CSV")
            import_csv_button = gr.UploadButton("Import from CSV", file_types=[".csv"])
        # Removed duplicate 'Regenerate Selected Dialogue' button; using the single one bound later

        def get_characters_and_configs():
            characters = db.get_characters()
            configs = db.get_llm_configs()
            
            # Handle empty characters list
            character_choices = [(c[1], c[0]) for c in characters] if characters else []
            
            # Handle empty configs list
            # 菜单项仅显示配置名称，不包含模型或API Key
            config_choices = [(c[1], c[0]) for c in configs] if configs else []
            
            return gr.update(choices=character_choices), gr.update(choices=config_choices)
        
        def refresh_llm_configs():
            """刷新LLM配置列表"""
            configs = db.get_llm_configs()
            # 菜单项仅显示配置名称，不包含模型或API Key
            config_choices = [(c[1], c[0]) for c in configs] if configs else []
            return gr.update(choices=config_choices)

        def generate_dialogue_streaming(character_id, llm_config_id, language):
            """流式生成对话，支持实时状态更新和停止功能"""
            if not character_id or not llm_config_id:
                yield (
                    initial_df,
                    "Please select a character and LLM configuration.",
                    "等待开始生成...",
                    "请先选择角色、API配置和语言",
                    gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                )
                return

            # 语言映射和列名映射
            language_map = {
                "中文": "Chinese",
                "English": "English", 
                "日本語": "Japanese"
            }
            column_map = {
                "中文": "台词",
                "English": "英文台词",
                "日本語": "日文台词"
            }
            
            target_language = language_map.get(language, "Chinese")
            dialogue_column = column_map.get(language, "台词")

            try:
                # 设置生成状态
                generation_state["is_running"] = True
                generation_state["stop_requested"] = False
                
                # 使用DialogueGenerator类进行对话生成
                from dialogue_generator import DialogueGenerator
                from action_parameters import ALL_ACTION_PARAMS
                generator = DialogueGenerator()
                
                # 获取角色和LLM配置信息
                character = db.get_character(character_id)
                llm_config = db.get_llm_config(llm_config_id)
                
                if not character or not llm_config:
                    generation_state["is_running"] = False
                    yield (
                        gr.update(value=initial_df, datatype=["bool", "str", "str"]),
                        "角色或LLM配置未找到",
                        "❌ 配置错误",
                        "请检查角色和LLM配置",
                        gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                    )
                    return
                
                # 立即生成并显示提示词模板
                prompt_template = create_concise_prompt_template(
                    character[1], character[2], target_language, ALL_ACTION_PARAMS[:3]
                )
                
                prompt_preview_text = f"""🎭 Character: {character[1]}
📝 Description: {character[2]}
🌐 Language: {target_language}
🤖 LLM: {llm_config[4]} @ {llm_config[2]}

📋 Task: Generate {len(ALL_ACTION_PARAMS)} dialogue lines
📦 Batches: {(len(ALL_ACTION_PARAMS) + 14) // 15} batches (15 per batch)

🔧 Prompt Template:
{json.dumps(prompt_template, ensure_ascii=False, indent=2)}

⚡ Status: Ready to send to LLM..."""
                
                # 立即显示提示词和更新按钮状态
                # 初始化实时表格副本用于逐行状态更新
                live_df = initial_df.copy()
                try:
                    if "选择" in live_df.columns:
                        live_df["选择"] = live_df["选择"].astype(bool)
                except Exception:
                    pass
                yield (
                    gr.update(value=live_df.copy(), datatype=["bool", "str", "str"]),
                    "🚀 开始生成...",
                    "📝 提示词已生成，准备发送给LLM...",
                    prompt_preview_text,
                    gr.update(value="Generating...", variant="secondary", interactive=False)
                )
                
                # 状态回调函数 - 收集所有状态信息
                status_messages = ["🚀 开始生成..."]
                def status_callback(message):
                    if generation_state["stop_requested"]:
                        return
                    status_messages.append(message)
                    print(f"Status: {message}")
                
                def progress_callback(current_action, current_index, total_count):
                    if generation_state["stop_requested"]:
                        return f"❌ 生成已停止"
                    progress_msg = f"正在生成第 {current_index + 1}/{total_count} 条: {current_action}"
                    status_messages.append(progress_msg)
                    # 将当前动作参数标记为“正在生成”
                    try:
                        mask = live_df['动作参数'].astype(str).str.strip() == str(current_action).strip()
                        if mask.any():
                            dlg_col_idx = 2 if live_df.shape[1] >= 3 else (live_df.shape[1] - 1)
                            dlg_col_name = live_df.columns[dlg_col_idx]
                            live_df.loc[mask, dlg_col_name] = '正在生成'
                        else:
                            print(f"[Table] 未找到参数以标记正在生成: {current_action}")
                    except Exception:
                        pass
                    print(f"Progress: {progress_msg}")
                    return progress_msg
                
                # 实时状态更新函数
                def update_status():
                    current_status = "\n".join(status_messages[-8:])
                    return current_status
                
                # 开始生成对话（在后台线程中）
                import threading
                import time
                
                result_holder = {"dialogues": None, "error": None}
                
                def run_generation():
                    try:
                        # 创建停止检查函数
                        def stop_check():
                            return generation_state["stop_requested"]
                        
                        # 表格更新回调：逐条写入生成结果
                        def table_update_callback(action, dialogue):
                            try:
                                mask = live_df['动作参数'].astype(str).str.strip() == str(action).strip()
                                updated_rows = int(mask.sum())
                                if updated_rows > 0:
                                    # 使用iloc安全更新所有匹配行的第二列
                                    idxs = live_df.index[mask]
                                    # 始终写入第三列（台词列），不依赖显示的表头文字
                                    dlg_col_idx = 2 if live_df.shape[1] >= 3 else (live_df.shape[1] - 1)
                                    for idx in idxs:
                                        live_df.iloc[idx, dlg_col_idx] = dialogue
                                    print(f"[Table] 更新 {updated_rows} 行: {action} -> {dialogue[:30]}...")
                                    status_messages.append(f"📥 表格已更新: {action}")
                                else:
                                    print(f"[Table] 未找到匹配参数: {action}")
                                    status_messages.append(f"⚠️ 表格未找到参数: {action}")
                            except Exception as e:
                                print(f"[Table] 更新失败: {e}")

                        result = generator.generate_dialogues_with_progress(
                            character_id, 
                            llm_config_id, 
                            target_language, 
                            "/Users/Saga/breathVOICE/台词.csv",
                            progress_callback=progress_callback,
                            status_callback=status_callback,
                            table_update_callback=table_update_callback,
                            stop_check=stop_check
                        )
                        result_holder["dialogues"] = result
                    except Exception as e:
                        result_holder["error"] = str(e)
                
                generation_thread = threading.Thread(target=run_generation, daemon=True)
                generation_thread.start()
                
                # 实时更新状态
                while generation_thread.is_alive():
                    if generation_state["stop_requested"]:
                        status_messages.append("❌ 用户请求停止生成")
                        break
                    
                    yield (
                        gr.update(value=live_df.copy(), datatype=["bool", "str", "str"]),  # 实时更新表格
                        gr.update(),  # 不更新status_output
                        update_status(),
                        gr.update(),  # 不更新提示词预览
                        gr.update(value="Generating...", variant="secondary", interactive=False)
                    )
                    time.sleep(0.5)  # 更快刷新，提高实时性
                
                generation_thread.join(timeout=1)  # 等待线程结束
                generation_state["is_running"] = False
                
                # 处理结果
                if generation_state["stop_requested"]:
                    yield (
                        gr.update(value=initial_df.copy(), datatype=["bool", "str", "str"]),
                        "❌ 生成已被用户停止",
                        update_status() + "\n❌ 生成已停止",
                        prompt_preview_text,
                        gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                    )
                elif result_holder["error"]:
                    yield (
                        gr.update(value=initial_df.copy(), datatype=["bool", "str", "str"]),
                        f"❌ 生成出错: {result_holder['error']}",
                        update_status() + f"\n❌ 错误: {result_holder['error']}",
                        prompt_preview_text,
                        gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                    )
                elif result_holder["dialogues"]:
                    # 最终以实时表格为准，确保逐行更新后的结果完整呈现
                    dialogue_df = live_df
                    yield (
                        gr.update(value=dialogue_df.copy(), datatype=["bool", "str", "str"]),
                        f"✅ 成功生成 {len(result_holder['dialogues'])} 条台词！",
                        update_status() + "\n🎉 生成完成！",
                        prompt_preview_text,
                        gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                    )
                else:
                    yield (
                        gr.update(value=initial_df.copy(), datatype=["bool", "str", "str"]),
                        "❌ 未能生成任何台词",
                        update_status() + "\n❌ 生成失败",
                        prompt_preview_text,
                        gr.update(value="Generate Dialogue", variant="primary", interactive=True)
                    )
                    
            except Exception as e:
                generation_state["is_running"] = False
                yield (
                    gr.update(value=initial_df, datatype=["bool", "str", "str"]),
                    f"生成台词时出错: {e}",
                    f"❌ 错误: {str(e)}",
                    f"错误详情: {str(e)}",
                    gr.update(value="Generate Dialogue", variant="primary")
                )
        
        def stop_generation():
            """停止生成（用于独立“Stop Generate”按钮）"""
            generation_state["stop_requested"] = True
            # 立即给出用户反馈：状态栏提示正在停止，并将按钮改为Stopping...
            return (
                "⛔️ 已发送停止请求，正在取消...",
                "⛔️ 用户请求停止，等待当前批次结束...",
                gr.update(value="Stopping...", variant="secondary", interactive=False)
            )

        def handle_button_click(character_id, llm_config_id, language):
            """处理按钮点击 - 开始生成或停止生成（生成器以支持流式）"""
            if generation_state["is_running"]:
                # 正在生成时，引导用户点击独立的 Stop 按钮
                yield (
                    gr.update(),
                    gr.update(value="⛔️ 正在生成中，请点击下方 Stop 取消"),
                    gr.update(),
                    gr.update(),
                    gr.update()
                )
            else:
                # 如果没有在生成，则开始生成（流式转发）
                yield from generate_dialogue_streaming(character_id, llm_config_id, language)

        def create_concise_prompt_template(character_name: str, character_description: str, 
                                         language: str, sample_params: list) -> dict:
            """创建简明的英文提示词模板"""
            return {
                "role": "adult_content_dialogue_generator",
                "task": f"Generate intimate dialogue for character '{character_name}' in {language}",
                "character": {
                    "name": character_name,
                    "description": character_description
                },
                "business_logic": {
                    "product": "Interactive adult companion with sensors",
                    "parameters": {
                        "greeting_X": "Welcome/startup dialogue",
                        "P[0-6]_orgasm_X": "Climax dialogue (P=position: 0=any, 1=missionary, 2=left, 3=right, 4=doggy, 5=cowgirl, 6=pressed)",
                        "P[0-6]_B[0-5]_reaction_X": "Arousal response (B=breathing: 0=calm, 1-5=excitement levels)",
                        "P[0-6]_B[0-5]_tease_X": "Playful/seductive dialogue when user pauses",
                        "P[0-6]_B[0-5]_impact_X": "Response to sudden stimulation",
                        "P[0-6]_B[0-5]_[LTit/RTit/LButt/RButt]_[long/short]_X": "Touch responses (body parts + duration)"
                    }
                },
                "requirements": {
                    "length": "1-50 characters per line",
                    "style": "Intimate, character-appropriate, emotionally authentic",
                    "format": "JSON: {'parameter': 'dialogue', ...}",
                    "language": language,
                    "content": "Adult content allowed, realistic expressions",
                    "user_addressing_rule": "Strict: Regardless of character description or any context (e.g., containing names like 'Proxy'), always address the user ONLY with the second-person pronoun — Chinese: '你'; English: 'you'; Japanese: 'あなた'. Never use names, nicknames, titles, or placeholders to address the user."
                },
                "example_params": sample_params
            }

        def preview_prompt(character_id, llm_config_id, language):
            """预览将要发送给LLM的提示词"""
            if not character_id or not llm_config_id:
                return "请先选择角色、API配置和语言"
            
            try:
                from dialogue_generator import DialogueGenerator
                generator = DialogueGenerator()
                
                # 获取角色信息
                character = db.get_character(character_id)
                if not character:
                    return "未找到角色信息"
                
                # 获取LLM配置
                config = db.get_llm_config(llm_config_id)
                if not config:
                    return "未找到LLM配置"
                
                # 语言映射
                language_map = {
                    "中文": "Chinese",
                    "English": "English", 
                    "日本語": "Japanese"
                }
                target_language = language_map.get(language, "Chinese")
                
                # 加载动作参数（取前3个作为示例）
                action_params = generator.load_action_parameters("/Users/Saga/breathVOICE/台词.csv")
                if not action_params:
                    return "无法加载动作参数"
                
                sample_actions = action_params[:3]  # 只取前3个作为示例
                
                # 创建示例提示词
                prompt = generator.create_prompt(character[1], character[2], sample_actions, target_language)
                
                return f"【角色】: {character[1]}\n【描述】: {character[2]}\n【语言】: {target_language}\n【LLM模型】: {config[3]}\n\n【提示词内容】:\n{prompt}\n\n注：以上仅显示前3个动作参数的示例提示词"
                
            except Exception as e:
                return f"预览提示词时出错: {str(e)}"

        def save_dialogue_set(character_id, language, dialogue_df):
            # 命名: 角色名 + 语言 + 日期 + 时间，且仅包含英文字母/数字/下划线
            if character_id and not dialogue_df.empty:
                character = db.get_character(character_id)
                character_name = character[1] if character else "Unknown"
                # 语言英文映射
                language_map = {"中文": "Chinese", "English": "English", "日本語": "Japanese"}
                lang_en = language_map.get(language, "Chinese")

                def ascii_token(text):
                    normalized = unicodedata.normalize('NFKD', str(text))
                    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
                    token = re.sub(r'[^A-Za-z0-9]+', '_', ascii_text)
                    token = token.strip('_')
                    return token

                char_token = ascii_token(character_name)
                if not char_token:
                    char_token = f"character_{character_id}"
                lang_token = ascii_token(lang_en)
                dt_token = datetime.now().strftime('%Y%m%d_%H%M%S')
                name = f"{char_token}_{lang_token}_{dt_token}"
                set_id = db.create_dialogue_set(character_id, name)
                for index, row in dialogue_df.iterrows():
                    # 使用列名，忽略“选择”列
                    action_param = row.get("动作参数") if "动作参数" in dialogue_df.columns else row.iloc[1]
                    # 兼容不同语言的台词列名
                    dlg_col = None
                    for col in ["台词", "英文台词", "日文台词"]:
                        if col in dialogue_df.columns:
                            dlg_col = col
                            break
                    dialogue = row.get(dlg_col) if dlg_col else row.iloc[-1]
                    db.create_dialogue(set_id, action_param, dialogue)
                return f"Dialogue set saved successfully as {name}!"
            else:
                return "Character and dialogue are required."

        def load_dialogue_set(set_id):
            if set_id:
                # 从数据库加载后，补充“选择”列（默认未选）
                dialogues = db.get_dialogues(set_id)
                df = pd.DataFrame(dialogues, columns=["动作参数", "台词"]) if dialogues else pd.DataFrame(columns=["动作参数", "台词"])
                if "选择" not in df.columns:
                    df.insert(0, "选择", False)
                try:
                    df["选择"] = df["选择"].astype(bool)
                except Exception:
                    pass
                return gr.update(value=df, datatype=["bool", "str", "str"])
            else:
                return gr.update(value=pd.DataFrame(columns=["选择", "动作参数", "台词"]), datatype=["bool", "str", "str"])

        def get_dialogue_sets(character_id):
            if character_id:
                sets = db.get_dialogue_sets(character_id)
                return gr.update(choices=[(s[2], s[0]) for s in sets])
            else:
                return gr.update(choices=[])

        def delete_dialogue_set(set_id):
            if set_id:
                db.delete_dialogue_set(set_id)
                return "Dialogue set deleted."
            return "No set selected."

        def export_to_csv(dialogue_df):
            if not dialogue_df.empty:
                # 导出时仅包含动作参数与当前语言台词列
                dlg_col = None
                for col in ["台词", "英文台词", "日文台词"]:
                    if col in dialogue_df.columns:
                        dlg_col = col
                        break
                export_df = dialogue_df[["动作参数", dlg_col]] if dlg_col else dialogue_df
                export_df.to_csv("dialogue.csv", index=False)
                return "Dialogue exported to dialogue.csv"
            else:
                return "No dialogue to export."

        def import_from_csv(character_id, file):
            if character_id and file is not None:
                try:
                    df = pd.read_csv(file.name)
                    set_name = f"imported_{os.path.basename(file.name)}"
                    set_id = db.create_dialogue_set(character_id, set_name)
                    # 支持不同的列名格式
                    if 'Action Parameter' in df.columns and 'Dialogue' in df.columns:
                        for _, row in df.iterrows():
                            db.create_dialogue(set_id, row['Action Parameter'], row['Dialogue'])
                    elif '动作参数' in df.columns:
                        # 找到台词列（可能是台词、中文台词、英文台词或日文台词）
                        dialogue_col = None
                        for col in ['台词', '中文台词', '英文台词', '日文台词']:
                            if col in df.columns:
                                dialogue_col = col
                                break
                        if dialogue_col:
                            for _, row in df.iterrows():
                                db.create_dialogue(set_id, row['动作参数'], row[dialogue_col])
                        else:
                            return "CSV file must contain a dialogue column (台词/中文台词/英文台词/日文台词).", gr.update()
                    else:
                        return "CSV file must contain '动作参数' or 'Action Parameter' column.", gr.update()
                    return "CSV imported successfully.", gr.update()
                except Exception as e:
                    return f"Error importing CSV: {e}", gr.update()
            return "Character and file must be selected.", gr.update()

        def regenerate_selected_dialogue(character_id, llm_config_id, language, dialogue_df, evt: gr.SelectData):
            if evt.index is None or character_id is None or llm_config_id is None:
                return dialogue_df, "Please select a row and ensure character and LLM config are selected."

            try:
                selected_row_index = evt.index[0]
                action_parameter = dialogue_df.iloc[selected_row_index, 1]  # 加入“选择”列后，第二列是动作参数

                character = db.get_character(character_id)
                llm_config = db.get_llm_config(llm_config_id)

                # 语言映射
                language_map = {
                    "中文": "Chinese",
                    "English": "English", 
                    "日本語": "Japanese"
                }
                target_language = language_map.get(language, "Chinese")

                client = openai.OpenAI(base_url=llm_config[2], api_key=llm_config[3])

                prompt = (
                    f"You are creating dialogue for a character named {character[1]}. {character[2]}\n"
                    f"The dialogue is for the action: {action_parameter}.\n"
                    f"Please generate a single line of dialogue in {target_language}.\n"
                    f"Important: STRICT RULE — Regardless of any names or titles present in the character description or context (e.g., 'Proxy'), always address the user ONLY with the second-person pronoun ('你' in Chinese, 'you' in English, 'あなた' in Japanese). Never use names, nicknames, titles, placeholders, or honorifics when addressing the user."
                )

                response = client.chat.completions.create(
                    model=llm_config[4],
                    messages=[
                        {"role": "system", "content": "You are a creative assistant for generating game character dialogues."},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=100
                )

                new_dialogue = response.choices[0].message.content.strip()
                
                # 更新DataFrame（台词列位于第3列）
                dialogue_df.iloc[selected_row_index, 2] = new_dialogue
                
                return dialogue_df, f"Regenerated dialogue for {action_parameter}"
                
            except Exception as e:
                return dialogue_df, f"Error regenerating dialogue: {e}"

        # 添加语言变化时更新表格列名的功能
        def update_table_headers(language):
            column_map = {
                "中文": "台词",
                "English": "英文台词",
                "日本語": "日文台词"
            }
            dialogue_column = column_map.get(language, "台词")
            return gr.update(headers=["选择", "动作参数", dialogue_column], datatype=["bool", "str", "str"]) 

        # 批量重新生成：勾选“选择”为True的行
        def regenerate_selected_dialogues(character_id, llm_config_id, language, dialogue_df):
            if character_id is None or llm_config_id is None:
                return dialogue_df, "Please select character and LLM config."
            try:
                character = db.get_character(character_id)
                llm_config = db.get_llm_config(llm_config_id)
                if not character or not llm_config:
                    return dialogue_df, "角色或LLM配置未找到"

                language_map = {
                    "中文": "Chinese",
                    "English": "English", 
                    "日本語": "Japanese"
                }
                target_language = language_map.get(language, "Chinese")

                client = openai.OpenAI(base_url=llm_config[2], api_key=llm_config[3])

                # 找到当前台词列名
                dlg_col = None
                for col in ["台词", "英文台词", "日文台词"]:
                    if col in dialogue_df.columns:
                        dlg_col = col
                        break
                if not dlg_col:
                    dlg_col = "台词"

                # 逐条处理勾选项
                updated = 0
                for idx, row in dialogue_df.iterrows():
                    if bool(row.get("选择", False)):
                        action_parameter = row.get("动作参数")
                        prompt = (
                            f"You are creating dialogue for a character named {character[1]}. {character[2]}\n"
                            f"The dialogue is for the action: {action_parameter}.\n"
                            f"Please generate a single line of dialogue in {target_language}.\n"
                            f"Important: STRICT RULE — Regardless of any names or titles present in the character description or context (e.g., 'Proxy'), always address the user ONLY with the second-person pronoun ('你' in Chinese, 'you' in English, 'あなた' in Japanese). Never use names, nicknames, titles, placeholders, or honorifics when addressing the user."
                        )
                        try:
                            response = client.chat.completions.create(
                                model=llm_config[4],
                                messages=[
                                    {"role": "system", "content": "You are a creative assistant for generating game character dialogues."},
                                    {"role": "user", "content": prompt}
                                ],
                                max_tokens=100
                            )
                            new_dialogue = response.choices[0].message.content.strip()
                            dialogue_df.at[idx, dlg_col] = new_dialogue
                            dialogue_df.at[idx, "选择"] = False  # 生成完成后取消选择
                            updated += 1
                        except Exception:
                            pass

                status_msg = f"Regenerated {updated} selected dialogues" if updated else "No rows selected"
                return dialogue_df, status_msg
            except Exception as e:
                return dialogue_df, f"Error: {e}"

        # 根据是否勾选“选择”列来切换批量重新生成按钮的可用状态
        def toggle_regenerate_button(df_value):
            try:
                has_selected = False
                if isinstance(df_value, pd.DataFrame):
                    if "选择" in df_value.columns:
                        has_selected = bool(df_value["选择"].astype(bool).any())
                else:
                    # 兼容非DataFrame结构（列表等），尝试转换
                    temp_df = pd.DataFrame(df_value) if df_value is not None else pd.DataFrame()
                    if not temp_df.empty:
                        # 假定第一列为选择列
                        has_selected = bool(temp_df.iloc[:, 0].astype(bool).any())
                return gr.update(interactive=has_selected)
            except Exception:
                return gr.update(interactive=False)

        # 绑定事件
        language_dropdown.change(update_table_headers, language_dropdown, dialogue_df)
        character_dropdown.change(get_dialogue_sets, character_dropdown, load_dialogue_set_dropdown)
        
        # 添加刷新LLM配置按钮的事件绑定
        refresh_llm_button.click(refresh_llm_configs, None, llm_config_dropdown)
        
        # 添加提示词预览功能的事件绑定
        def update_prompt_preview(character_id, llm_config_id, language):
            return preview_prompt(character_id, llm_config_id, language)
        
        # 移除旧的提示词预览事件绑定，因为现在提示词只在点击生成时显示
        # character_dropdown.change(update_prompt_preview, [character_dropdown, llm_config_dropdown, language_dropdown], prompt_preview)
        # llm_config_dropdown.change(update_prompt_preview, [character_dropdown, llm_config_dropdown, language_dropdown], prompt_preview)
        # language_dropdown.change(update_prompt_preview, [character_dropdown, llm_config_dropdown, language_dropdown], prompt_preview)
        
        # 修改生成按钮的事件绑定，支持流式输出和动态按钮；抓取事件句柄以供取消
        gen_evt = generate_button.click(
            handle_button_click,
            [character_dropdown, llm_config_dropdown, language_dropdown],
            [dialogue_df, status_output, generation_status, prompt_preview, generate_button],
            concurrency_limit=2
        )

        # 独立的停止按钮：直接通过 Gradio 取消机制终止正在运行/排队的生成事件
        stop_button.click(
            stop_generation,
            None,
            [status_output, generation_status, generate_button]
        )

        # 批量重新生成按钮
        regenerate_selected_button = gr.Button("Regenerate Selected Dialogue", variant="secondary", interactive=False)
        regenerate_selected_button.click(
            regenerate_selected_dialogues,
            [character_dropdown, llm_config_dropdown, language_dropdown, dialogue_df],
            [dialogue_df, status_output]
        )
        # 当表格内容发生变化（特别是“选择”列勾选）时，更新按钮可用状态
        dialogue_df.change(toggle_regenerate_button, dialogue_df, regenerate_selected_button)
        
        
        save_dialogue_set_button.click(save_dialogue_set, [character_dropdown, language_dropdown, dialogue_df], status_output).then(get_dialogue_sets, character_dropdown, load_dialogue_set_dropdown)
        load_dialogue_set_dropdown.change(load_dialogue_set, load_dialogue_set_dropdown, dialogue_df).then(
            toggle_regenerate_button, dialogue_df, regenerate_selected_button
        )
        delete_dialogue_set_button.click(delete_dialogue_set, load_dialogue_set_dropdown, status_output)
        export_csv_button.click(export_to_csv, dialogue_df, status_output)
        import_csv_button.upload(import_from_csv, [character_dropdown, import_csv_button], [status_output, load_dialogue_set_dropdown]).then(get_dialogue_sets, character_dropdown, load_dialogue_set_dropdown)
        dialogue_df.select(regenerate_selected_dialogue, [character_dropdown, llm_config_dropdown, language_dropdown, dialogue_df], [dialogue_df, status_output])

        dialogue_generation_interface.load(get_characters_and_configs, None, [character_dropdown, llm_config_dropdown])

    return dialogue_generation_interface

def voice_generation_ui():
    with gr.Blocks() as voice_generation_ui:
        gr.Markdown("## Step 4: Voice Generation")
        with gr.Row():
            character_dropdown = gr.Dropdown(label="Select Character")
            dialogue_set_dropdown = gr.Dropdown(label="Select Dialogue Set")
        with gr.Row():
            voice_id_dropdown = gr.Dropdown(label="Select VoiceID") # Placeholder
            reference_audio = gr.Audio(label="Reference Audio (Optional)", type="filepath")
        with gr.Row():
            generate_voices_button = gr.Button("Generate Voices")
            clear_completed_button = gr.Button("Clear Completed")
            regenerate_voice_button = gr.Button("Regenerate Selected Voice")

        generation_progress = gr.Dataframe(headers=["Action Parameter", "Dialogue", "Status", "Preview"], col_count=(4, "fixed"))

        def get_characters_and_dialogue_sets():
            characters = db.get_characters()
            character_choices = [(c[1], c[0]) for c in characters]
            if character_choices:
                dialogue_sets = db.get_dialogue_sets(character_choices[0][1])
                dialogue_set_choices = [(ds[1], ds[0]) for ds in dialogue_sets]
                return gr.update(choices=character_choices, value=character_choices[0][1]), gr.update(choices=dialogue_set_choices)
            return gr.update(choices=[]), gr.update(choices=[])

        def update_dialogue_sets(character_id):
            dialogue_sets = db.get_dialogue_sets(character_id)
            dialogue_set_choices = [(ds[1], ds[0]) for ds in dialogue_sets]
            return gr.update(choices=dialogue_set_choices)

        def update_generation_tasks(set_id):
            if not set_id:
                return gr.update(value=[])
            dialogues = db.get_dialogues(set_id)
            tasks = [[d[0], d[1], "Pending", None] for d in dialogues]
            return gr.update(value=tasks)

        def generate_voices(tasks):
            output_dir = "output"
            os.makedirs(output_dir, exist_ok=True)

            for i, task in enumerate(tasks):
                if task[2] == "Pending":
                    action_parameter = task[0]
                    dialogue = task[1]
                    wav_path = os.path.join(output_dir, f"{action_parameter}.wav")

                    # Simulate voice generation
                    duration = len(dialogue.split()) * 0.5 # Estimate duration
                    sr = 48000
                    silence = np.zeros(int(duration * sr))
                    sf.write(wav_path, silence, sr)

                    tasks[i][2] = "Completed"
                    tasks[i][3] = wav_path
                    yield gr.Dataframe.update(value=tasks)

        def regenerate_voice(evt: gr.SelectData):
            if evt.index is not None:
                generation_progress.value[evt.index[0]][2] = "Pending"
                generation_progress.value[evt.index[0]][3] = None
                return gr.Dataframe.update(value=generation_progress.value)

        def clear_completed_tasks():
            tasks = generation_progress.value
            pending_tasks = [task for task in tasks if task[2] == "Pending"]
            return gr.Dataframe.update(value=pending_tasks)

        character_dropdown.change(update_dialogue_sets, character_dropdown, dialogue_set_dropdown)
        dialogue_set_dropdown.change(update_generation_tasks, dialogue_set_dropdown, generation_progress)
        generate_voices_button.click(generate_voices, generation_progress, generation_progress)
        regenerate_voice_button.click(regenerate_voice, None, generation_progress)
        clear_completed_button.click(clear_completed_tasks, None, generation_progress)

        voice_generation_ui.load(get_characters_and_dialogue_sets, None, [character_dropdown, dialogue_set_dropdown])

    return voice_generation_ui

def export_ui():
    with gr.Blocks() as export_interface:
        gr.Markdown("## Step 5: Export Voice Pack")
        character_dropdown = gr.Dropdown(label="Select Character")
        export_button = gr.Button("Export Voice Pack")
        download_link = gr.File(label="Download Voice Pack")

        def get_characters():
            characters = db.get_characters()
            return gr.update(choices=[(c[1], c[0]) for c in characters])

        def export_voice_pack(character_id):
            if not character_id:
                return None

            character = db.get_character(character_id)
            character_name = character[1]
            source_dir = os.path.join("output", character_name)
            zip_path = os.path.join("output", f"{character_name}.zip")

            # Define folder structure
            folders = {
                "greeting": ["greeting_"],
                "orgasm": ["orgasm_"],
                "reaction": ["reaction_"],
                "tease": ["tease_"],
                "impact": ["impact_"],
                "touch": ["touch_"]
            }

            with zipfile.ZipFile(zip_path, 'w') as zf:
                files_to_add = [f for f in os.listdir(source_dir) if f.endswith('.wav')]
                progress(0, desc="Starting archive creation...")
                for i, filename in enumerate(files_to_add):
                    progress(i / len(files_to_add), desc=f"Adding {filename}")
                    source_file_path = os.path.join(source_dir, filename)
                    found_folder = False
                    for folder, prefixes in folders.items():
                        for prefix in prefixes:
                            if filename.startswith(prefix):
                                zf.write(source_file_path, os.path.join(character_name, folder, filename))
                                found_folder = True
                                break
                        if found_folder:
                            break
                    if not found_folder:
                        zf.write(source_file_path, os.path.join(character_name, filename))

            return zip_path

        export_interface.load(get_characters, None, character_dropdown)
        export_button.click(export_voice_pack, [character_dropdown], download_link)

    return export_interface


if __name__ == "__main__":
    db.initialize_database()

    iface = gr.TabbedInterface([
        character_ui(),
        llm_config_ui(),
        dialogue_generation_ui(),
        voice_generation_ui(),
        export_ui()
    ], ["Character Management", "LLM Configuration", "Dialogue Generation", "Voice Generation", "Export Voice Pack"])

    iface.launch(inbrowser=True, server_port=7863, share=False)